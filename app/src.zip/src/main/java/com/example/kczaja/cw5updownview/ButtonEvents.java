package com.example.kczaja.cw5updownview;

import android.view.View;

/**
 * Created by kczaja on 05.04.2017.
 */

public class ButtonEvents implements View.OnClickListener, View.OnLongClickListener {
    @Override
    public void onClick(View view) {

    }

    @Override
    public boolean onLongClick(View view) {
        return false;
    }
}
